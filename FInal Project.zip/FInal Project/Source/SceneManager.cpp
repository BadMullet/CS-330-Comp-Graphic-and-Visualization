///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";

}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Start with no textures loaded.
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method loads the textures used in the scene.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// Load the textures
	CreateGLTexture("../../Utilities/textures/handle.jpg", "handle");
	CreateGLTexture("../../Utilities/textures/coffee.jpg", "coffee");
	CreateGLTexture("../../Utilities/textures/mug_nasa1.png", "mug");
	CreateGLTexture("../../Utilities/textures/wood.jpg", "wood");
	CreateGLTexture("../../Utilities/textures/mousepad_texture.jpg", "mousePad");
	CreateGLTexture("../../Utilities/textures/keyboard.jpg", "keyboardTop");
	CreateGLTexture("../../Utilities/textures/laptop.jpg", "laptopTop");
	CreateGLTexture("../../Utilities/textures/rightscreen.jpg", "rightScreen");
	CreateGLTexture("../../Utilities/textures/leftscreen.jpg", "leftScreen");
	CreateGLTexture("../../Utilities/textures/laptopscreen.jpg", "laptopScreen");
	CreateGLTexture("../../Utilities/textures/black_texture.jpg", "black");
	CreateGLTexture("../../Utilities/textures/wall.jpg", "wall");
	CreateGLTexture("../../Utilities/textures/ceiling.jpg", "ceiling");

	// Bind the loaded textures to the available texture slots.
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines the materials used by the objects
 *  on the desk.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL material;

	// Remove any old material definitions.
	m_objectMaterials.clear();

	/****************************************************************/

	// Create a material for the wooden desktop.
	material.ambientColor = glm::vec3(0.35f, 0.25f, 0.15f);
	material.ambientStrength = 0.015f;
	material.diffuseColor = glm::vec3(0.48f, 0.40f, 0.32f);
	material.specularColor = glm::vec3(0.22f, 0.17f, 0.11f);
	material.shininess = 3.0f;
	material.tag = "woodMaterial";
	m_objectMaterials.push_back(material);

	/****************************************************************/

	// Create a material for black plastic objects.
	material.ambientColor = glm::vec3(0.05f, 0.05f, 0.05f);
	material.ambientStrength = 0.025f;
	material.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
	material.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
	material.shininess = 1.00f;
	material.tag = "blackPlasticMaterial";
	m_objectMaterials.push_back(material);

	/****************************************************************/

	// Create a material for the laptop and metal parts.
	material.ambientColor = glm::vec3(0.25f, 0.25f, 0.25f);
	material.ambientStrength = 0.020f;
	material.diffuseColor = glm::vec3(0.55f, 0.55f, 0.55f);
	material.specularColor = glm::vec3(0.70f, 0.70f, 0.70f);
	material.shininess = 2.00f;
	material.tag = "metalMaterial";
	m_objectMaterials.push_back(material);

	/****************************************************************/

	// Create a glossy ceramic material for the mug.
	material.ambientColor = glm::vec3(0.60f, 0.60f, 0.60f);
	material.ambientStrength = 0.060f;
	material.diffuseColor = glm::vec3(0.72f, 0.72f, 0.72f);
	material.specularColor = glm::vec3(0.65f, 0.65f, 0.65f);
	material.shininess = 1.50f;
	material.tag = "ceramicMaterial";
	m_objectMaterials.push_back(material);

	/****************************************************************/

	// Create a material for the powered screens.
	material.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	material.ambientStrength = 0.040f;
	material.diffuseColor = glm::vec3(0.20f, 0.20f, 0.20f);
	material.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	material.shininess = 0.05f;
	material.tag = "screenMaterial";
	m_objectMaterials.push_back(material);

	/****************************************************************/

	// Create a glossy material for the coffee surface.
	material.ambientColor = glm::vec3(0.08f, 0.04f, 0.02f);
	material.ambientStrength = 0.020f;
	material.diffuseColor = glm::vec3(0.24f, 0.12f, 0.05f);
	material.specularColor = glm::vec3(0.50f, 0.50f, 0.50f);
	material.shininess = 2.00f;
	material.tag = "liquidMaterial";
	m_objectMaterials.push_back(material);

	/****************************************************************/

	// Create a dull material for the walls and ceiling.
	material.ambientColor = glm::vec3(0.55f, 0.55f, 0.55f);
	material.ambientStrength = 0.015f;
	material.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	material.specularColor = glm::vec3(0.03f, 0.03f, 0.03f);
	material.shininess = 0.10f;
	material.tag = "wallMaterial";
	m_objectMaterials.push_back(material);

	/****************************************************************/

	// Create a dull material for the mouse pad.
	material.ambientColor = glm::vec3(0.20f, 0.20f, 0.20f);
	material.ambientStrength = 0.020f;
	material.diffuseColor = glm::vec3(0.32f, 0.32f, 0.32f);
	material.specularColor = glm::vec3(0.03f, 0.03f, 0.03f);
	material.shininess = 0.10f;
	material.tag = "fabricMaterial";
	m_objectMaterials.push_back(material);

	// Create a softer material for the side walls.
	material.ambientColor = glm::vec3(0.35f, 0.35f, 0.35f);
	material.ambientStrength = 0.010f;
	material.diffuseColor = glm::vec3(0.28f, 0.28f, 0.28f);
	material.specularColor = glm::vec3(0.02f, 0.02f, 0.02f);
	material.shininess = 0.05f;
	material.tag = "sideWallMaterial";
	m_objectMaterials.push_back(material);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method sets up the lighting for the desk scene.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Turn on custom lighting for the scene.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Reset all four lights before setting them up.
	for (int i = 0; i < 4; i++)
	{
		std::string lightName =
			"lightSources[" + std::to_string(i) + "]";

		m_pShaderManager->setVec3Value(
			lightName + ".position",
			0.0f, -100.0f, 0.0f);

		m_pShaderManager->setVec3Value(
			lightName + ".ambientColor",
			0.0f, 0.0f, 0.0f);

		m_pShaderManager->setVec3Value(
			lightName + ".diffuseColor",
			0.0f, 0.0f, 0.0f);

		m_pShaderManager->setVec3Value(
			lightName + ".specularColor",
			0.0f, 0.0f, 0.0f);

		m_pShaderManager->setFloatValue(
			lightName + ".focalStrength",
			32.0f);

		m_pShaderManager->setFloatValue(
			lightName + ".specularIntensity",
			0.0f);
	}

	/****************************************************************/
	// Light 0: Neutral white main light for the room.
	m_pShaderManager->setVec3Value(
		"lightSources[0].position",
		-4.0f, 9.0f, 8.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[0].ambientColor",
		0.010f, 0.010f, 0.010f);

	m_pShaderManager->setVec3Value(
		"lightSources[0].diffuseColor",
		0.20f, 0.20f, 0.20f);

	m_pShaderManager->setVec3Value(
		"lightSources[0].specularColor",
		0.08f, 0.08f, 0.08f);

	m_pShaderManager->setFloatValue(
		"lightSources[0].focalStrength",
		32.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[0].specularIntensity",
		0.05f);

	/****************************************************************/
	// Light 1: Warm yellow light near the desk lamp.
	m_pShaderManager->setVec3Value(
		"lightSources[1].position",
		0.0f, 11.5f, -4.5f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].ambientColor",
		0.015f, 0.011f, 0.006f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].diffuseColor",
		0.26f, 0.19f, 0.09f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].specularColor",
		0.10f, 0.07f, 0.035f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].focalStrength",
		32.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].specularIntensity",
		0.08f);

	/****************************************************************/
	// Light 2: Soft blue light from the left monitor.
	m_pShaderManager->setVec3Value(
		"lightSources[2].position",
		-6.5f, 6.0f, -6.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[2].ambientColor",
		0.003f, 0.005f, 0.010f);

	m_pShaderManager->setVec3Value(
		"lightSources[2].diffuseColor",
		0.05f, 0.08f, 0.16f);

	m_pShaderManager->setVec3Value(
		"lightSources[2].specularColor",
		0.02f, 0.03f, 0.06f);

	m_pShaderManager->setFloatValue(
		"lightSources[2].focalStrength",
		16.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[2].specularIntensity",
		0.02f);

	/****************************************************************/
	// Light 3: Soft blue light from the right monitor.
	m_pShaderManager->setVec3Value(
		"lightSources[3].position",
		6.5f, 6.0f, -6.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[3].ambientColor",
		0.003f, 0.005f, 0.010f);

	m_pShaderManager->setVec3Value(
		"lightSources[3].diffuseColor",
		0.05f, 0.08f, 0.16f);

	m_pShaderManager->setVec3Value(
		"lightSources[3].specularColor",
		0.02f, 0.03f, 0.06f);

	m_pShaderManager->setFloatValue(
		"lightSources[3].focalStrength",
		16.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[3].specularIntensity",
		0.02f);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

	// Load the textures used in the scene.
	LoadSceneTextures();

	// Define the materials used in the scene.
	DefineObjectMaterials();

	// Set up the lights used by the scene.
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();

	// Load the shapes needed to create the coffee mug.
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();

	// Load the box mesh for the keyboard, laptop, and monitors.
	m_basicMeshes->LoadBoxMesh();

	// Load the sphere mesh used to create the mouse.
	m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the wood texture to the desktop.
	SetShaderTexture("wood");

	// Repeat the wood pattern across the large plane.
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("woodMaterial");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/

	// Draw the walls around the desk scene.
	RenderWalls();
	
	// Draw the mug using the separate mug method.
	RenderMug();

	// Draw the keyboard near the front of the desk.
	RenderKeyboard();

	// Draw the mouse pad to the right of the keyboard.
	RenderMousePad();

	// Draw the laptop behind the keyboard.
	RenderLaptop();

	// Draw the mouse on top of the mouse pad.
	RenderMouse();

	// Draw the large monitor on the left side of the desk.
	RenderLeftMonitor();

	// Draw the monitor on the right side of the desk.
	RenderRightMonitor();

	// Draw the desk lamp behind the laptop.
	RenderLamp();
}

/***********************************************************
 *  RenderMug()
 *
 *  This method draws the mug body, coffee, and handle.
 ***********************************************************/
void SceneManager::RenderMug()
{
	// Variables used for each part of the mug.
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/****************************************************************/

	// Draw the cylinder used for the mug body.
	scaleXYZ = glm::vec3(1.7f, 2.0f, 1.7f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// Move the mug up so it sits on the desktop.
	positionXYZ = glm::vec3(-7.4f, 0.05f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the mug texture to the body.
	SetShaderTexture("mug");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("ceramicMaterial");

	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/

	// Draw a thin cylinder for the coffee.
	scaleXYZ = glm::vec3(1.4f, 0.04f, 1.4f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the coffee near the top of the mug.
	positionXYZ = glm::vec3(-7.4f, 2.02f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the coffee texture to the liquid.
	SetShaderTexture("coffee");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("liquidMaterial");

	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/

	// Draw the torus used for the mug handle.
	scaleXYZ = glm::vec3(0.75f, 0.75f, 0.22f);

	// Turn the torus so it stands upright.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// Move the handle to the right side of the mug.
	positionXYZ = glm::vec3(-5.75f, 1.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the handle texture and repeat it around the torus.
	SetShaderTexture("handle");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("ceramicMaterial");

	m_basicMeshes->DrawTorusMesh();

}
/***********************************************************
 *  RenderKeyboard()
 *
 *  This method creates the keyboard using a box mesh and
 *  places it near the front-center of the desk.
 ***********************************************************/
void SceneManager::RenderKeyboard()
{
	// Set the size of the keyboard.
	glm::vec3 scaleXYZ = glm::vec3(10.5f, 0.20f, 2.0f);

	// Keep the keyboard flat on the desk.
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// Place the keyboard near the front-center of the desk.
	glm::vec3 positionXYZ = glm::vec3(0.0f, 0.12f, 3.6f);

	// Apply the scale, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the keyboard a dark gray color.
	SetShaderColor(
		0.08f,
		0.08f,
		0.08f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the keyboard using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create a thin top panel for the keyboard texture.
	scaleXYZ = glm::vec3(10.0f, 0.03f, 1.8f);

	// Keep the top panel flat.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the panel slightly above the keyboard base.
	positionXYZ = glm::vec3(0.0f, 0.23f, 3.6f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the keyboard texture.
	SetShaderTexture("keyboardTop");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the textured top panel.
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
*  RenderMousePad()
*
*  This method creates the mouse pad using a thin box mesh
*  and places it to the right of the keyboard.
***********************************************************/
void SceneManager::RenderMousePad()
{
	// Set the size of the mouse pad.
	glm::vec3 scaleXYZ = glm::vec3(4.8f, 0.2f, 3.2f);

	// Keep the mouse pad flat on the desktop.
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	
	// Place the mouse pad to the right of the keyboard.
	glm::vec3 positionXYZ = glm::vec3(8.0f, 0.02f, 2.7f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the galaxy texture to the mouse pad.
	SetShaderTexture("mousePad");

	// Show the texture once across the mouse pad.
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("fabricMaterial");

	// Draw the mouse pad using the box mesh.
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderLaptop()
 *
 *  This method creates the laptop using two box meshes.
 *  One box is used for the base, and the other is used
 *  for the screen.
 ***********************************************************/
void SceneManager::RenderLaptop()
{
	// Variables used for each part of the laptop.
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

/****************************************************************/

	// Set the size of the laptop base.
	scaleXYZ = glm::vec3(9.5f, 0.25f, 4.8f);

	// Keep the laptop base flat on the desktop.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the laptop base behind the keyboard.
	positionXYZ = glm::vec3(0.0f, 0.20f, -0.6f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the laptop base a light gray color.
	SetShaderColor(
		0.45f,
		0.45f,
		0.45f,
		1.0f);

	SetShaderMaterial("metalMaterial");

	// Draw the laptop base using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create a thin top panel for the laptop texture.
	scaleXYZ = glm::vec3(8.8f, 0.03f, 4.2f);

	// Keep the top panel flat.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the panel slightly above the laptop base.
	positionXYZ = glm::vec3(0.0f, 0.34f, -0.6f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the laptop texture.
	SetShaderTexture("laptopTop");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("metalMaterial");

	// Draw the textured top panel.
	m_basicMeshes->DrawBoxMesh();

/****************************************************************/

	// Set the size of the laptop screen.
	scaleXYZ = glm::vec3(9.5f, 5.4f, 0.18f);

	// Tilt the screen slightly backward.
	XrotationDegrees = -10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the screen at the back of the laptop base.
	positionXYZ = glm::vec3(0.0f, 2.95f, -2.8f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the laptop screen a dark color.
	SetShaderColor(
		0.04f,
		0.04f,
		0.04f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the laptop screen using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create a smaller panel for the visible laptop screen area.
	scaleXYZ = glm::vec3(8.7f, 4.8f, 0.03f);

	// Keep the screen panel lined up with the laptop screen frame.
	XrotationDegrees = -10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the screen panel slightly in front of the laptop screen frame.
	positionXYZ = glm::vec3(0.0f, 2.95f, -2.62f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the laptop screen texture.
	SetShaderTexture("laptopScreen");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("screenMaterial");

	// Keep the powered screen bright.
	m_pShaderManager->setBoolValue(g_UseLightingName, false);

	// Draw the visible laptop screen area using a thin box mesh.
	m_basicMeshes->DrawBoxMesh();

	// Turn the scene lighting back on for the remaining objects.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}

/***********************************************************
 *  RenderLeftMonitor()
 *
 *  This method creates the left monitor using box
 *  meshes for the screen, stand, and base.
 ***********************************************************/
void SceneManager::RenderLeftMonitor()
{
	// Variables used for each part of the monitor.
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/****************************************************************/

	// Set the size of the left monitor screen.
	scaleXYZ = glm::vec3(11.5f, 6.5f, 0.25f);

	// Turn the monitor slightly toward the center of the desk.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 10.0f;
	ZrotationDegrees = 0.0f;

	// Place the screen behind the mug and left of the laptop.
	positionXYZ = glm::vec3(-10.5f, 5.75f, -4.2f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the monitor frame a nearly black color.
	SetShaderColor(
		0.03f,
		0.03f,
		0.03f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the monitor screen using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

		// Create a smaller rectangle for the visible screen area.
	scaleXYZ = glm::vec3(10.7f, 5.7f, 0.03f);

	// Keep the screen panel lined up with the monitor body.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 10.0f;
	ZrotationDegrees = 0.0f;

	// Place the screen panel slightly in front of the monitor body.
	positionXYZ = glm::vec3(-10.47f, 5.75f, -4.04f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the left monitor screen texture.
	SetShaderTexture("leftScreen");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("screenMaterial");

	// Keep the powered screen bright.
	m_pShaderManager->setBoolValue(g_UseLightingName, false);

	// Draw the visible screen area using a thin box mesh.
	m_basicMeshes->DrawBoxMesh();

	// Turn the scene lighting back on.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/****************************************************************/

	// Set the size of the monitor stand.
	scaleXYZ = glm::vec3(0.9f, 3.3f, 0.75f);

	// Keep the stand upright.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 10.0f;
	ZrotationDegrees = 0.0f;

	// Place the stand below the monitor screen.
	positionXYZ = glm::vec3(-10.35f, 1.75f, -4.55f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the stand a dark gray color.
	SetShaderColor(
		0.08f,
		0.08f,
		0.08f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the monitor stand using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Set the size of the monitor base.
	scaleXYZ = glm::vec3(4.5f, 0.20f, 2.6f);

	// Keep the base flat on the desktop.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 10.0f;
	ZrotationDegrees = 0.0f;

	// Place the base underneath the monitor stand.
	positionXYZ = glm::vec3(-10.25f, 0.12f, -4.0f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the base a dark gray color.
	SetShaderColor(
		0.08f,
		0.08f,
		0.08f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the monitor base using the box mesh.
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderRightMonitor()
 *
 *  This method creates the right monitor using box meshes
 *  for the frame, screen panel, stand, and base.
 ***********************************************************/
void SceneManager::RenderRightMonitor()
{
	// Variables used for each part of the monitor.
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/****************************************************************/

	// Set the size of the right monitor frame.
	scaleXYZ = glm::vec3(11.5f, 6.5f, 0.25f);

	// Turn the monitor slightly toward the center of the desk.
	XrotationDegrees = 0.0f;
	YrotationDegrees = -10.0f;
	ZrotationDegrees = 0.0f;

	// Place the monitor to the right of the laptop.
	positionXYZ = glm::vec3(10.5f, 5.75f, -4.2f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the outside monitor frame a dark color.
	SetShaderColor(
		0.03f,
		0.03f,
		0.03f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the monitor frame using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create a smaller rectangle for the visible screen area.
	scaleXYZ = glm::vec3(10.7f, 5.7f, 0.03f);

	// Keep the screen panel lined up with the monitor frame.
	XrotationDegrees = 0.0f;
	YrotationDegrees = -10.0f;
	ZrotationDegrees = 0.0f;

	// Place the screen panel slightly in front of the frame.
	positionXYZ = glm::vec3(10.47f, 5.75f, -4.04f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the right monitor screen texture.
	SetShaderTexture("rightScreen");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("screenMaterial");

	// Keep the powered screen bright.
	m_pShaderManager->setBoolValue(g_UseLightingName, false);

	// Draw the visible screen area using a thin box mesh.
	m_basicMeshes->DrawBoxMesh();

	// Turn the scene lighting back on.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/****************************************************************/

	// Set the size of the monitor stand.
	scaleXYZ = glm::vec3(0.9f, 3.3f, 0.75f);

	// Keep the stand turned with the monitor.
	XrotationDegrees = 0.0f;
	YrotationDegrees = -10.0f;
	ZrotationDegrees = 0.0f;

	// Place the stand below and behind the monitor frame.
	positionXYZ = glm::vec3(10.35f, 1.75f, -4.55f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the monitor stand a dark gray color.
	SetShaderColor(
		0.08f,
		0.08f,
		0.08f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the monitor stand using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Set the size of the monitor base.
	scaleXYZ = glm::vec3(4.5f, 0.20f, 2.6f);

	// Keep the base flat on the desktop.
	XrotationDegrees = 0.0f;
	YrotationDegrees = -10.0f;
	ZrotationDegrees = 0.0f;

	// Place the base underneath the monitor stand.
	positionXYZ = glm::vec3(10.25f, 0.12f, -4.0f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the monitor base a dark gray color.
	SetShaderColor(
		0.08f,
		0.08f,
		0.08f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the monitor base using the box mesh.
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderLamp()
 *
 *  This method creates the base and upright support for
 *  the desk lamp behind the laptop.
 ***********************************************************/
void SceneManager::RenderLamp()
{
	// Variables used for each part of the lamp.
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/****************************************************************/

	// Create a short, wide cylinder for the lamp base.
	scaleXYZ = glm::vec3(1.5f, 0.20f, 1.5f);

	// Keep the lamp base flat on the desktop.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the lamp base behind the laptop.
	positionXYZ = glm::vec3(-1.0f, 0.05f, -5.5f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the lamp base a nearly black color.
	SetShaderColor(
		0.03f,
		0.03f,
		0.03f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the lamp base using the cylinder mesh.
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/

	// Create a narrow, tall cylinder for the upright support.
	scaleXYZ = glm::vec3(0.38f, 10.0f, 0.38f);

	// Keep the lamp support standing upright.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the support on top of the lamp base.
	positionXYZ = glm::vec3(-1.0f, 0.20f, -5.5f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the upright support the same dark color.
	SetShaderColor(
		0.03f,
		0.03f,
		0.03f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the upright support using the cylinder mesh.
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/

	// Create an angled cylinder for the upper part of the lamp.
	scaleXYZ = glm::vec3(0.38f, 2.6f, 0.38f);

	// Lean the upper support toward the center of the desk.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -18.0f;

	// Connect the upper support to the top of the upright section.
	positionXYZ = glm::vec3(-1.0f, 9.6f, -5.5f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the upper support the same dark color.
	SetShaderColor(
		0.03f,
		0.03f,
		0.03f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the angled upper support.
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/

	// Create a small center piece where the light bars connect.
	scaleXYZ = glm::vec3(0.65f, 0.32f, 0.65f);

	// Keep the center piece level.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the center piece at the top of the lamp support.
	positionXYZ = glm::vec3(0.0f, 11.85f, -5.5f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the center piece the same dark color.
	SetShaderColor(
		0.03f,
		0.03f,
		0.03f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the center piece using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create the light bar extending to the left.
	scaleXYZ = glm::vec3(5.2f, 0.28f, 0.65f);

	// Angle the left light bar slightly upward.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -8.0f;

	// Place the left light bar beside the center piece.
	positionXYZ = glm::vec3(-2.9f, 11.95f, -5.5f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the outside of the light bar a dark color.
	SetShaderColor(
		0.03f,
		0.03f,
		0.03f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the left light bar.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create the light bar extending to the right.
	scaleXYZ = glm::vec3(5.2f, 0.28f, 0.65f);

	// Angle the right light bar slightly upward.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 8.0f;

	// Place the right light bar beside the center piece.
	positionXYZ = glm::vec3(2.9f, 11.95f, -5.5f);

	// Apply the size, rotation, and position values.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the outside of the light bar a dark color.
	SetShaderColor(
		0.03f,
		0.03f,
		0.03f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the right light bar.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Keep the light strips bright so the lamp looks turned on.
	m_pShaderManager->setBoolValue(g_UseLightingName, false);

	// Create the light strip underneath the left lamp bar.
	scaleXYZ = glm::vec3(4.7f, 0.08f, 0.42f);

	// Match the angle of the left lamp bar.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -8.0f;

	// Place the light strip slightly below and in front of the bar.
	positionXYZ = glm::vec3(-2.9f, 11.78f, -5.15f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the light strip a bright white color.
	SetShaderColor(
		0.95f,
		0.95f,
		0.90f,
		1.0f);

	SetShaderMaterial("screenMaterial");

	// Draw the light strip using a thin box mesh.
	m_basicMeshes->DrawBoxMesh();

	// Turn the scene lighting back on.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/****************************************************************/

	// Keep the light strips bright so the lamp looks turned on.
	m_pShaderManager->setBoolValue(g_UseLightingName, false);

	// Create the light strip underneath the right lamp bar.
	scaleXYZ = glm::vec3(4.7f, 0.08f, 0.42f);

	// Match the angle of the right lamp bar.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 8.0f;

	// Place the light strip slightly below and in front of the bar.
	positionXYZ = glm::vec3(2.9f, 11.78f, -5.15f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the light strip a bright white color.
	SetShaderColor(
		0.95f,
		0.95f,
		0.90f,
		1.0f);

	SetShaderMaterial("screenMaterial");

	// Draw the light strip using a thin box mesh.
	m_basicMeshes->DrawBoxMesh();

	// Turn the scene lighting back on.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}


/***********************************************************
 *  RenderMouse()
 *
 *  This method creates the mouse using a rounded body,
 *  a button panel, and a scroll wheel.
 ***********************************************************/
void SceneManager::RenderMouse()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/****************************************************************/

	// Create the rounded body of the mouse.
	scaleXYZ = glm::vec3(0.52f, 0.20f, 0.68f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the mouse on top of the mouse pad.
	positionXYZ = glm::vec3(8.0f, 0.40f, 2.75f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the mouse body a dark gray color.
	SetShaderColor(
		0.12f,
		0.12f,
		0.12f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the mouse body.
	m_basicMeshes->DrawSphereMesh();

	/****************************************************************/

	// Create a thin panel for the mouse buttons.
	scaleXYZ = glm::vec3(0.34f, 0.008f, 0.24f);

	XrotationDegrees = -4.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the panel almost flush with the mouse body.
	positionXYZ = glm::vec3(8.0f, 0.585f, 2.43f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the panel the same color as the mouse body.
	SetShaderColor(
		0.12f,
		0.12f,
		0.12f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the rounded button panel.
	m_basicMeshes->DrawSphereMesh();

	/****************************************************************/

	// Create the seam between the left and right buttons.
	scaleXYZ = glm::vec3(0.008f, 0.006f, 0.22f);

	XrotationDegrees = -4.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the seam down the center of the button panel.
	positionXYZ = glm::vec3(8.0f, 0.615f, 2.37f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the seam a black color.
	SetShaderColor(
		0.01f,
		0.01f,
		0.01f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the center seam.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create the opening for the scroll wheel.
	scaleXYZ = glm::vec3(0.055f, 0.006f, 0.10f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the opening behind the mouse buttons.
	positionXYZ = glm::vec3(8.0f, 0.618f, 2.55f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the opening a black color.
	SetShaderColor(
		0.01f,
		0.01f,
		0.01f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the wheel opening.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create the scroll wheel.
	scaleXYZ = glm::vec3(0.025f, 0.055f, 0.025f);

	// Turn the cylinder sideways.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// Place the wheel inside the opening.
	positionXYZ = glm::vec3(8.0f, 0.642f, 2.55f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Give the wheel a medium gray color.
	SetShaderColor(
		0.24f,
		0.24f,
		0.24f,
		1.0f);

	SetShaderMaterial("blackPlasticMaterial");

	// Draw the scroll wheel.
	m_basicMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  RenderWalls()
 *
 *  This method creates a back wall and a side wall using
 *  large, thin box meshes.
 ***********************************************************/
void SceneManager::RenderWalls()
{
	// Variables used for each wall.
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/****************************************************************/

	// Create a wide and tall back wall.
	scaleXYZ = glm::vec3(40.0f, 18.0f, 0.20f);

	// Keep the back wall standing upright.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the back wall behind the desk objects.
	positionXYZ = glm::vec3(0.0f, 9.0f, -10.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the wall texture.
	SetShaderTexture("wall");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("wallMaterial");

	// Draw the back wall using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create a tall and deep wall on the left side.
	scaleXYZ = glm::vec3(0.20f, 18.0f, 20.0f);

	// Keep the side wall standing upright.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the wall along the left side of the scene.
	positionXYZ = glm::vec3(-20.0f, 9.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the wall texture.
	SetShaderTexture("wall");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("sideWallMaterial");

	// Draw the side wall using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Make the right wall deep enough to match the desktop.
	scaleXYZ = glm::vec3(0.20f, 18.0f, 20.0f);

	// Keep the right wall standing upright.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the right wall along the right edge of the desktop.
	positionXYZ = glm::vec3(20.0f, 9.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the wall texture.
	SetShaderTexture("wall");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("sideWallMaterial");

	// Draw the right wall using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	// Create a wide, thin box for the ceiling.
	scaleXYZ = glm::vec3(40.0f, 0.20f, 20.0f);

	// Keep the ceiling flat above the room.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the ceiling at the top of the walls.
	positionXYZ = glm::vec3(0.0f, 18.0f, 0.0f);

	// Apply the ceiling transformations.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the ceiling texture.
	SetShaderTexture("ceiling");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("sideWallMaterial");

	// Draw the ceiling.
	m_basicMeshes->DrawBoxMesh();
}